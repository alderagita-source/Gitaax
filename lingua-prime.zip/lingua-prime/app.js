const $ = s => document.querySelector(s);
const K_USERS = 'lp_users', K_SESSION = 'lp_session';
const users = () => JSON.parse(localStorage.getItem(K_USERS) || '[]');
const session = () => JSON.parse(localStorage.getItem(K_SESSION) || 'null');

async function hash(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}
function say(el, text, type) { el.textContent = text; el.className = 'msg ' + type; }

// Navbar: ubah tombol jika sudah login
const navBtn = $('#navAuth');
if (navBtn && session()) { navBtn.textContent = 'Dashboard'; navBtn.href = 'dashboard.html'; }

// Halaman login/daftar
if ($('#loginForm')) {
  if (session()) location.href = 'dashboard.html';
  document.querySelectorAll('.tabs button').forEach(t => t.onclick = () => {
    document.querySelectorAll('.tabs button,form').forEach(e => e.classList.remove('on'));
    t.classList.add('on'); $('#' + t.dataset.f).classList.add('on');
  });

  $('#registerForm').onsubmit = async e => {
    e.preventDefault(); const m = $('#regMsg');
    const name = $('#rName').value.trim(), email = $('#rEmail').value.trim().toLowerCase();
    const pass = $('#rPass').value, level = $('#rLevel').value;
    if (pass.length < 8) return say(m, 'Password minimal 8 karakter.', 'err');
    const list = users();
    if (list.some(u => u.email === email)) return say(m, 'Email sudah terdaftar.', 'err');
    list.push({ name, email, level, pass: await hash(pass) });
    localStorage.setItem(K_USERS, JSON.stringify(list));
    say(m, 'Pendaftaran berhasil! Silakan masuk.', 'ok');
    setTimeout(() => $('[data-f=loginForm]').click(), 900);
  };

  $('#loginForm').onsubmit = async e => {
    e.preventDefault(); const m = $('#logMsg');
    const email = $('#lEmail').value.trim().toLowerCase(), pass = await hash($('#lPass').value);
    const u = users().find(x => x.email === email && x.pass === pass);
    if (!u) return say(m, 'Email atau password salah.', 'err');
    localStorage.setItem(K_SESSION, JSON.stringify({ name: u.name, email: u.email, level: u.level }));
    location.href = 'dashboard.html';
  };
}

// Dashboard (halaman terproteksi)
if ($('#dash')) {
  const s = session();
  if (!s) location.href = 'login.html';
  else {
    $('#uName').textContent = s.name.split(' ')[0];
    $('#uLevel').textContent = s.level;
  }
  $('#logout').onclick = () => { localStorage.removeItem(K_SESSION); location.href = 'index.html'; };
}
