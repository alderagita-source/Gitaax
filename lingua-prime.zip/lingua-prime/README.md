# LinguaPrime – Platform Bimbel Bahasa Inggris Tingkat Lanjut

Website statis (HTML, CSS, JavaScript) dengan landing page, sistem login/daftar, dan dashboard siswa. Siap di-host gratis di **GitHub Pages**.

## Struktur File
| File | Fungsi |
|---|---|
| `index.html` | Landing page (hero, keunggulan, program, testimoni, CTA) |
| `login.html` | Halaman masuk & daftar |
| `dashboard.html` | Halaman siswa (hanya bisa dibuka setelah login) |
| `style.css` | Seluruh tampilan (responsif) |
| `app.js` | Logika login, daftar, sesi, dan logout |

## Cara Deploy ke GitHub Pages
1. Buat repository baru di GitHub (mis. `lingua-prime`).
2. Upload semua file di folder ini ke repository.
3. Buka **Settings → Pages**.
4. Pada *Source*, pilih branch `main` dan folder `/ (root)`, lalu **Save**.
5. Tunggu 1–2 menit; situs aktif di `https://username.github.io/lingua-prime/`.

## Cara Jalankan Lokal
Buka `index.html` di browser, atau gunakan server lokal (disarankan agar fitur hashing berjalan):
```bash
python -m http.server 8000
```

## ⚠️ Catatan Keamanan Penting
GitHub Pages hanya menyajikan **file statis**, tidak ada server/database. Karena itu:
- Akun disimpan di `localStorage` browser masing-masing pengguna (bukan database bersama).
- Password di-hash SHA-256, tetapi **sistem ini hanya cocok untuk demo/prototipe**, bukan untuk data siswa sungguhan.
- Halaman `dashboard.html` bisa dilewati oleh pengguna yang paham teknis.

**Untuk produksi**, gunakan layanan autentikasi sungguhan seperti [Firebase Authentication](https://firebase.google.com/docs/auth) atau [Supabase Auth](https://supabase.com/docs/guides/auth), dengan frontend tetap di GitHub Pages.

## Kustomisasi
- Ganti nama/brand: cari `LinguaPrime` di semua file.
- Warna: ubah variabel di bagian `:root` pada `style.css`.
- Harga, program, dan testimoni: edit `index.html` (ganti testimoni contoh dengan yang asli).

## Lisensi
MIT – bebas digunakan dan dimodifikasi.
